-- Execute no Console D1 para conferir a estrutura que já foi criada.
SELECT name
FROM sqlite_master
WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
ORDER BY name;

-- Deve listar categories, products, customers, orders, order_items, settings e audit_logs.
