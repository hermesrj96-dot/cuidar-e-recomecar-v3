-- CUIDAR E RECOMEÇAR V3 — IMPORTAÇÃO SEGURA DO CATÁLOGO V2
-- Este script NÃO cria nem apaga tabelas. Ele usa o D1 existente.
-- Pode ser executado novamente: categorias e produtos já existentes são ignorados.

INSERT OR IGNORE INTO categories(name, description, active) VALUES ('Smartphones', 'Celulares e smartphones', 1);
INSERT OR IGNORE INTO categories(name, description, active) VALUES ('Air Fryers', 'Fritadeiras elétricas e forno air fryer', 1);

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Samsung Galaxy A17 5G 256GB 8GB RAM', 'TOP 1 • Produto novo • Samsung A17 5G, 256 GB, 8 GB RAM, câmera de 50 MP.', 1300.65, NULL, 'https://http2.mlstatic.com/D_NQ_NP_889169-MLA96868779849_102025-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Samsung Galaxy A17 5G 256GB 8GB RAM');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Samsung Galaxy A07 4G 256GB 8GB RAM', 'TOP 2 • Produto novo • Samsung A07 4G, 256 GB, 8 GB RAM.', 1169.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_895724-MLA91526198522_092025-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Samsung Galaxy A07 4G 256GB 8GB RAM');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Motorola Moto G06 128GB 4GB RAM', 'TOP 3 • Produto novo • Moto G06, 128 GB, 4 GB RAM, bateria de 5.200 mAh.', 899.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_950509-MLA104892646697_012026-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Motorola Moto G06 128GB 4GB RAM');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Motorola Moto G17 128GB', 'TOP 4 • Produto novo • Moto G17 4G, 128 GB, câmera Sony Lytia.', 949.99, NULL, 'https://http2.mlstatic.com/D_NQ_NP_773592-MLA105493148200_012026-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Motorola Moto G17 128GB');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Motorola Moto G35 5G 128GB', 'TOP 5 • Produto novo • Moto G35 5G, 128 GB, NFC.', 1259.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_652780-MLA97095974098_112025-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Motorola Moto G35 5G 128GB');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Motorola Moto G06 256GB', 'TOP 6 • Produto novo • Moto G06, 256 GB, câmera de 50 MP.', 949.05, NULL, 'https://http2.mlstatic.com/D_NQ_NP_793349-MLA91806774304_092025-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Motorola Moto G06 256GB');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Samsung Galaxy A17 5G 128GB', 'TOP 7 • Produto novo • Galaxy A17 5G, 128 GB.', 1299.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_889169-MLA96868779849_102025-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Samsung Galaxy A17 5G 128GB');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Samsung Galaxy A07 128GB', 'TOP 8 • Produto novo • Galaxy A07, 128 GB, 4G.', 878.8, NULL, 'https://http2.mlstatic.com/D_NQ_NP_895724-MLA91526198522_092025-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Samsung Galaxy A07 128GB');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Motorola Moto G56 5G 256GB', 'TOP 9 • Produto novo • Moto G56 5G, 256 GB, 8 GB RAM.', 1540.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_950509-MLA104892646697_012026-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Motorola Moto G56 5G 256GB');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Smartphones' LIMIT 1), 'Xiaomi Redmi 15C 256GB', 'TOP 10 • Produto novo • Redmi 15C, 256 GB, bateria de 6.000 mAh.', 1189.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_793349-MLA91806774304_092025-F.jpg', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Xiaomi Redmi 15C 256GB');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Elgin Quad Fry 4,2L 1400W 127V', 'TOP 1 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Elgin Quad Fry, 4,2 litros, 1.400 W.', 159.9, NULL, 'https://http2.mlstatic.com/D_NQ_NP_831652-MLA119453464213_102026-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Elgin Quad Fry 4,2L 1400W 127V');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Britânia Oven 11L BAF11A 1800W 220V', 'TOP 2 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Britânia Oven, 11 litros, 8 funções, 1.800 W.', 329.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_866410-MLA106357490185_022026-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Britânia Oven 11L BAF11A 1800W 220V');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Britânia Oven 11L BAF11A 1800W 127V', 'TOP 3 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Britânia Oven, 11 litros, 8 funções, 1.800 W.', 329.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_866410-MLA106357490185_022026-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Britânia Oven 11L BAF11A 1800W 127V');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Philco Air Fryer 6,5L PAF65A 1700W', 'TOP 4 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Philco 6,5 litros, visor glass, 1.700 W.', 287.5, NULL, 'https://http2.mlstatic.com/D_NQ_NP_761173-MLA99475995202_112025-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Philco Air Fryer 6,5L PAF65A 1700W');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Mondial Air Fryer 4L AFN-40-BFT 1500W', 'TOP 5 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Mondial, 4 litros, 1.500 W.', 195.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_775407-MLA99776749612_122025-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Mondial Air Fryer 4L AFN-40-BFT 1500W');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Britânia Redstone 6,5L BAF65A 1700W 127V', 'TOP 6 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Britânia Redstone, 6,5 litros, 8 funções.', 329.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_606677-MLA115733886141_082026-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Britânia Redstone 6,5L BAF65A 1700W 127V');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Philco Oven 16L PAF16C Digital 220V', 'TOP 7 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Philco Oven, 16 litros, painel digital e visor.', 346.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_825323-MLA120068143527_102026-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Philco Oven 16L PAF16C Digital 220V');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Philco Oven 11L PAF11B 1800W', 'TOP 8 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Philco Oven, 11 litros, 8 funções.', 389.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_633098-MLA92276027266_092025-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Philco Oven 11L PAF11B 1800W');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Britânia Redstone 6,5L BAF65A 1700W 220V', 'TOP 9 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Britânia Redstone, 6,5 litros, 8 funções.', 329.0, NULL, 'https://http2.mlstatic.com/D_NQ_NP_606677-MLA115733886141_082026-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Britânia Redstone 6,5L BAF65A 1700W 220V');

INSERT INTO products(category_id, name, description, price, entry_price, image_url, stock, active, featured)
SELECT (SELECT id FROM categories WHERE name='Air Fryers' LIMIT 1), 'Electrolux Rita Lobo EAF40 5,6L 1400W', 'TOP 10 • Produto novo • Preço de referência consultado no Mercado Livre em outubro/2026. Electrolux EAF40, 5,6 litros, 1.400 W.', 298.73, NULL, 'https://http2.mlstatic.com/D_NQ_NP_775407-MLA99776749612_122025-O.webp', 0, 1, 1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Electrolux Rita Lobo EAF40 5,6L 1400W');
